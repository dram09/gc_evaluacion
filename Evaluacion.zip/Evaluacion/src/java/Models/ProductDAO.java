/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Config.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dennis
 */

public class ProductDAO {
    
    Connect connect = new Connect();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public Product validate(String nombre, Double precio){
        
        Product product = new Product();
        
        String sql = "call DA_spGC_ABC_Productos (?,?,?,?,?,?,?)";
       
                
        try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setString(2, nombre);
            ps.setDouble(3, precio);
            ps.setInt(4, 0);
            ps.setInt(5, 0);
            ps.setInt(6, 2);
            ps.setInt(7, 0);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                product.setId(rs.getInt("Result"));
                 
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return product;
    }
    
    public List all(){
        
         String sql = "call DA_spGC_GET_Productos (?,?)";
         List<Product> lista = new  ArrayList<>();
         
        
                 
         try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setInt(2, 1);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                Product p =  new Product();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setPrecio(rs.getDouble("precio"));
                p.setEstatus(rs.getInt("activo"));
                p.setStock(rs.getInt("stock"));
                lista.add(p);
                 
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return lista;
         
    }
    public int store(Product p){
           String sql = "call DA_spGC_ABC_Productos (?,?,?,?,?,?,?)";
           
           try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setString(2,p.getNombre());
            ps.setDouble(3,p.getPrecio());
            ps.setInt(4,0);
            ps.setInt(5,0);
            ps.setInt(6,2);
            ps.setInt(7,0);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                r = rs.getInt("Result");
                 
            }
            
        }catch(Exception e){
            System.out.println(e);
        }
        return r;
    }
    
    public int update(int id){
        String sql = "call DA_spGC_ABC_Productos (?,?,?,?,?,?,?)";
           
           try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 2);
            ps.setString(2,"");
            ps.setDouble(3,0);
            ps.setInt(4,1);
            ps.setInt(5,0);
            ps.setInt(6,2);
            ps.setInt(7,id);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                r = rs.getInt("Result");
                 
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return r;
    }
    
    public int deactivate(int id,int estatus){
        
        String sql = "call DA_spGC_ABC_Productos (?,?,?,?,?,?,?)";
           
           try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 3);
            ps.setString(2,"");
            ps.setDouble(3,0);
            ps.setInt(4,1);
            ps.setInt(5,estatus);
            ps.setInt(6,2);
            ps.setInt(7,id);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                r = rs.getInt("Result");
                 
            }
            
        }catch(Exception e){
            System.out.println(e);
        }
        return r;
    }
    
}
