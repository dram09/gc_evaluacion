/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Config.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dennis
 */
public class UserDAO {
    
    Connect connect = new Connect();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public List all(){
        
         String sql = "call DA_spGC_GET_Usuarios(?,?)";
         List<User> lista = new  ArrayList<>();
         
         try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setInt(2, 0);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                User us =  new User();
                us.setId(rs.getInt("id"));
                us.setNombre(rs.getString("usuario"));
                us.setCorreo(rs.getString("correo"));
                us.setUsuario(rs.getString("nombre_usuario"));
                us.setRol(rs.getString("rol"));
                lista.add(us);
            }
 
        }catch(Exception e){
            System.out.println(e);
        }
        return lista;
         
    }
}
