/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Config.Connect;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author dennis
 */
public class AuthDAO {
    
    Connect connect = new Connect();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    CallableStatement cst;
    
    public User validate(String user, String password){
        
        User us = new User();
        
        String sql = "call DA_spGC_Acceso (?,?,?,?)";
                
        try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setString(2, user);
            ps.setString(3, password);
            ps.setInt(4, 0);
            rs = ps.executeQuery();
                    
            while(rs.next())
            {
                us.setId(rs.getInt("id"));
                us.setNombre(rs.getString("nombre"));
                us.setApellido_p(rs.getString("apellido_p"));
                us.setApellido_m(rs.getString("apellido_m"));
                us.setCorreo(rs.getString("correo"));
                us.setUsuario(rs.getString("usuario"));
                String [] vect = rs.getString("modulos").split(",");
                us.setModulos(vect);
                  
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return us;
    }
}
