/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Config.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author dennis
 */
public class CatDAO {
    
    Connect connect = new Connect();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    int r;
       
     public List products(){
        
         String sql = "call DA_spGC_Catalogos(?,?)";
         List<Product> lista = new  ArrayList<>();
         
         try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setInt(2, 0);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                Product p =  new Product();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                lista.add(p);
            }
 
        }catch(Exception e){
            System.out.println(e);
        }
        return lista;
         
    }
}
