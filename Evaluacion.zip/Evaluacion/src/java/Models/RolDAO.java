/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.util.ArrayList;
import java.util.List;

import Config.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dennis
 */
public class RolDAO {
    
    Connect connect = new Connect();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public List all(){
        
         String sql = "call DA_spGC_GET_Roles(?,?)";
         List<Rol> lista = new  ArrayList<>();
         
         try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setInt(2, 1);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                Rol rol =  new Rol();
                rol.setId(rs.getInt("id"));
                rol.setNombre(rs.getString("nombre"));
                String [] vect = rs.getString("modulos").split(",");
                rol.setModulos(vect);
                lista.add(rol);
                 
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return lista;
         
    }
    
}
