/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Config.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dennis
 */
public class SaleDAO {
    
    Connect connect = new Connect();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    int r;
       
   
    public List all(){
        
         String sql = "call DA_spGC_GET_Ventas(?,?)";
         List<Sale> lista = new  ArrayList<>();
         
         try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setInt(2, 0);
            rs = ps.executeQuery();
            
            while(rs.next())
            {
                Sale s =  new Sale();
                s.setId(rs.getInt("id"));
                s.setNombre(rs.getString("nombre"));
                s.setPrecio(rs.getDouble("precio"));
                s.setCantidad(rs.getInt("cantidad"));
                s.setTotal(rs.getDouble("total"));
                s.setUsuario(rs.getString("usuario"));
                s.setFecha(rs.getString("fecha"));
                lista.add(s);
            }
 
        }catch(Exception e){
            System.out.println(e);
        }
        return lista;
         
    }
    public int store(Sale s){
           String sql = "call DA_spGC_ABC_Ventas (?,?,?,?,?)";
           
           try{
            
            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setInt(2,s.getId_producto());
            ps.setInt(3,s.getCantidad());
            ps.setInt(4,2);
            ps.setInt(5,0);
            rs = ps.executeQuery();
           
            while(rs.next())
            {
                r = rs.getInt("Result");
            }

        }catch(Exception e){
            System.out.println(e);
        }
        return r;
    }

}
