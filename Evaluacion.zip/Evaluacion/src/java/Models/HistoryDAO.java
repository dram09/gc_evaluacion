/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import Config.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dennis
 */
public class HistoryDAO {

    Connect connect = new Connect();
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    int r;

    public List filter(int filtro) {

        String sql = "call DA_spGC_Historial (?,?)";
        List<History> lista = new ArrayList<>();

        try {

            conn = connect.Connect();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, filtro);
            ps.setInt(2, 0);
            rs = ps.executeQuery();

            if (filtro == 1) {

                while (rs.next()) {
                    History h = new History();
                    h.setNombre(rs.getString("nombre"));
                    h.setPrecio(rs.getDouble("precio"));
                    h.setStock(rs.getInt("stock"));
                    h.setUsuario(rs.getString("usuario"));
                    h.setFecha(rs.getString("fecha"));
                    lista.add(h);

                }
            } else {
                while (rs.next()) {
                    History h = new History();
                    h.setNombre(rs.getString("nombre"));
                    h.setPrecio(rs.getDouble("precio"));
                    h.setCantidad(rs.getInt("cantidad"));
                    h.setTotal(rs.getDouble("total"));
                    h.setUsuario(rs.getString("usuario"));
                    h.setFecha(rs.getString("fecha"));
                    lista.add(h);

                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return lista;

    }

}
