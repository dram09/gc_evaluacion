/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author dennis
 */
public class Rol {
     
    String nombre;
    String [] modulos;
    int id;
    
    public Rol() {

    }
    
    public Rol(String nombre, String [] modulos) {
        this.nombre = nombre;
        this.modulos = modulos;
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String[] getModulos() {
        return modulos;
    }

    public void setModulos(String [] modulos) {
        this.modulos = modulos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
}
