/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controllers;

import Models.CatDAO;
import Models.History;
import Models.HistoryDAO;
import Models.Product;
import Models.ProductDAO;
import Models.Rol;
import Models.RolDAO;
import Models.Sale;
import Models.SaleDAO;
import Models.User;
import Models.UserDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;

/**
 *
 * @author dennis
 */
public class Controller extends HttpServlet {

    Product product = new Product();
    ProductDAO productdao = new ProductDAO();

    CatDAO catdao = new CatDAO();

    Sale sale = new Sale();
    SaleDAO saledao = new SaleDAO();

    History history = new History();
    HistoryDAO historydao = new HistoryDAO();

    Rol rol = new Rol();
    RolDAO roldao = new RolDAO();

    User user = new User();
    UserDAO userdao = new UserDAO();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String menu = request.getParameter("menu");
        String action = request.getParameter("action");

        if (menu.equals("master")) {
            request.getRequestDispatcher("master.jsp").forward(request, response);
        }

        if (menu.equals("productos")) {

            switch (action) {

                case "listar":
                    List list = productdao.all();
                    request.setAttribute("result_list", list);
                    break;

                case "agregar":
                    String nombre = request.getParameter("nombre");
                    String precio = request.getParameter("precio");
                    product.setNombre(nombre);
                    product.setPrecio(Double.parseDouble(precio));
                    int r1 = productdao.store(product);

                    switch (r1) {
                        case 1:
                            request.setAttribute("alert_success", "Producto ingresado correctamente");
                            break;
                        case -1:
                            request.setAttribute("alert_warning", "El producto no pudo ser actualizado");
                            break;
                        default:
                            request.setAttribute("alert_error", "Ocurrio un error al intentar ejecutar la instrucción");
                            break;

                    }

                    request.getRequestDispatcher("Controller?menu=productos&action=listar").forward(request, response);
                    break;

                case "actualizar":

                    int id = Integer.parseInt(request.getParameter("id"));

                    int r_2 = productdao.update(id);

                    switch (r_2) {
                        case 1:
                            request.setAttribute("alert_success", "Aumento de producto correctamente");
                            break;
                        case -1:
                            request.setAttribute("alert_warning", "El producto no pudo ser aumentado");
                            break;
                        default:
                            request.setAttribute("alert_error", "Ocurrio un error al intentar ejecutar la instrucción");
                            break;

                    }

                    request.getRequestDispatcher("Controller?menu=productos&action=listar").forward(request, response);
                    break;

                case "desactivar":

                    int id_r = Integer.parseInt(request.getParameter("id"));
                    int estatus = Integer.parseInt(request.getParameter("estatus"));

                    int r = productdao.deactivate(id_r, estatus);

                    switch (r) {
                        case 1:
                            request.setAttribute("alert_success", "Estatus del registro actualizado correctamente");
                            System.out.println("Registro ingresado");
                            break;
                        case -1:
                            request.setAttribute("alert_warning", "El Estatus del registro no pudo ser actualizado");
                            break;
                        default:
                            request.setAttribute("alert_error", "Ocurrio un error al intentar ejecutar la instrucción");
                            break;

                    }

                    request.getRequestDispatcher("Controller?menu=productos&action=listar").forward(request, response);
                    break;

                default:
                    throw new AssertionError();
            }
            request.getRequestDispatcher("productos.jsp").forward(request, response);
        }
        if (menu.equals("ventas")) {

            switch (action) {

                case "listar":
                    List list = catdao.products();
                    request.setAttribute("result_products", list);

                    List list_all = saledao.all();
                    request.setAttribute("list_all", list_all);

                    break;

                case "agregar":
                    String producto = request.getParameter("producto");
                    String cantidad = request.getParameter("cantidad");
                    sale.setId_producto(Integer.parseInt(producto));
                    sale.setCantidad(Integer.parseInt(cantidad));

                    int r = saledao.store(sale);

                    switch (r) {
                        case 1:
                            request.setAttribute("alert_success", "Registro ingresado corretamente");
                            System.out.println("Registro ingresado");
                            break;
                        case -1:
                            request.setAttribute("alert_warning", "La cantidad ingresada es mayor a la de stock del producto");
                            break;
                        default:
                            request.setAttribute("alert_error", "El registro no pudo ser ingresado");
                            break;

                    }
                    request.getRequestDispatcher("Controller?menu=ventas&action=listar").forward(request, response);
                    break;

                default:
                    throw new AssertionError();
            }

            request.getRequestDispatcher("ventas.jsp").forward(request, response);
        }
        if (menu.equals("historial")) {

            switch (action) {

                case "listar":
                    
                       break;
                case "filtrar":

                    int filtro = Integer.parseInt(request.getParameter("filtro"));

                    List list = historydao.filter(filtro);
                    if (filtro == 1) {
                        request.setAttribute("list_filter_e", list);
                    }else{
                        request.setAttribute("list_filter_s", list);
                    }
                   

                    break;

                default:
                    throw new AssertionError();
            }

            request.getRequestDispatcher("historial.jsp").forward(request, response);
        }

        if (menu.equals("roles")) {

            switch (action) {

                case "listar":

                    List list = roldao.all();
                    request.setAttribute("list_all", list);

                    break;

                default:
                    throw new AssertionError();
            }
            request.getRequestDispatcher("roles.jsp").forward(request, response);
        }
        if (menu.equals("usuarios")) {

            switch (action) {

                case "listar":

                    List list = userdao.all();
                    request.setAttribute("list_all", list);

                    break;

                default:
                    throw new AssertionError();
            }
            request.getRequestDispatcher("usuarios.jsp").forward(request, response);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
