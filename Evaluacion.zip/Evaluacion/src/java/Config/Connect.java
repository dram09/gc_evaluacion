/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Config;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author dennis
 */
public class Connect {
   
    Connection connect;
    
    String url = "jdbc:mysql://localhost:3306/grupocastores";
    String user = "root";
    String password = "";
    
    public Connection Connect (){
       try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           connect = DriverManager.getConnection(url,user,password);
       }catch(Exception e){
          System.out.println(e);
       }
       return connect;
    }
    
}
