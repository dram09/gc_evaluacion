(function($) {
    "use strict";
    var id = 0;
    var form_valid = true;

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('.pagar').click(function(e) {
    
        e.preventDefault();
        $('#fecha').val('');
        $('#hora').val('');
        id = $(this).attr('href');
        $("#ModalPago").modal();

    });

    $('#registrar').on('click',function(e) {

           e.preventDefault();
        
           validate($('#fecha'));
           validate($('#hora'));

            var formData = new FormData;
            formData.append("estatus", 1);
            formData.append("fecha", $('#fecha').val() +' '+$('#hora').val());

            console.log($('#fecha').val() +' '+$('#hora').val());
            $.ajax({
                url: '/Aguapotable/multas/update&id='+id,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                cache: false,
                beforeSend: function() {
                    $('#ModalPago').modal('toggle');
                },
            }).done(function(data) {
                switch(data){
                    case -1:
                            $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
                        break;
                    case -2:
                            $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
                        break;
                    case -3:
                            $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
                        break;
                    default:
                            $.notify("Registro ingresado correctamente!", 'success');
                            window.location.href = '/Aguapotable/multas/show&id='+data;
                        break;
                }
            }).fail(function(data) {

                $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
            });

    });


    function validate(input) {

        if ($(input).val().trim() == '') {
            form_valid = false;
        }
    }

})(jQuery);