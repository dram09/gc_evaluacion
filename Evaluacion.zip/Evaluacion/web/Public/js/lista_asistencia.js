
(function ($) {
    "use strict";

    var formValid = true;

    $('#btn-search').on('click', function() {
        $(window).attr('location', 'index&reunion=' + $('select[name=reunion]').val());
    });

    $('#btn-print-list').on('click', function() {
        window.open('/Aguapotable/docs/lista_asistencias&id_reunion=' + $('select[name=reunion]').val());
        //$(window).attr('location', '/Aguapotable/docs/pagos_contratos&fecha=' + $('#fecha').val()).attr('target','_blank');
    });

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(".saved").each(function () {

        $(this).click(function () {

            formValid = true;

            //var boton = $(this).parents("tr").find(".saved");
            //boton.prop('disabled', true);

            var reunion = $("select[name=reunion]").val();
            var contrato = $(this).parents("tr").find("input[name=contrato]").val();
            var fecha = $(this).parents("tr").find("input[name=fecha]").val();
            var hora = $(this).parents("tr").find("input[name=hora]").val();
            var asistencia = $(this).parents("tr").find("select[name=asistencia]").val();
            var observacion = $(this).parents("tr").find("input[name=observacion]").val();

            valuesrequired(reunion);
            valuesrequired(contrato);
            valuesrequired(fecha);
            valuesrequired(hora);
            valuesrequired(asistencia);
            valuesrequired(observacion);

            if (formValid) {


                var formData = new FormData;
                formData.append("reunion", reunion);
                formData.append("contrato", contrato);
                formData.append("fecha", fecha + ' ' + hora);
                formData.append("asistencia", asistencia);
                formData.append("observacion", observacion);

                console.log(formData);
                $.ajax({
                    url: '/Aguapotable/listas_asistencias/store',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    cache: false,
                }).done(function (data) {
                    switch (data) {
                        case -1:
                            $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
                            break;
                        case -2:
                            $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
                            break;
                        case -3:
                            $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
                            break;
                        default:
                            $.notify("Registro ingresado correctamente!", 'success');
                            //boton.prop('disabled', true);
                            break;
                    }
                }).fail(function (data) {
                    $.notify("Ocurrio un error, intentalo mas tarde, o cantacta a soporte!", 'danger');
                });

            } else {
                $.notify("Favor de completar todos los campos", 'warning');
            }
        });

    });

    function valuesrequired(Valor) {
        if (Valor == null || Valor.length == 0 || /^\s+$/.test(Valor) || Valor === undefined) {
            formValid = false;
        }
    }


})(jQuery);