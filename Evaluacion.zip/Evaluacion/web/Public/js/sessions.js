
jQuery(document).ready(function($) {
    'use strict';

    $( ".nav-link-menu" ).each(function( index ) {
        $(this).text() == sessionStorage.getItem('module') ? $(this).addClass('active') : '' ;
      });

    $('.nav-link-menu').on('click', function(){
        sessionStorage.setItem('module',$(this).text());
      });
});