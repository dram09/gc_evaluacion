(function($) {
    "use strict";

    $('#btn-search').on('click', function() {
        $(window).attr('location', 'index&fecha=' + $('#fecha').val());
    });
    $('#btn-print-list').on('click', function() {
        window.open('/Aguapotable/docs/pagos_contratos&fecha=' + $('#fecha').val());
        //$(window).attr('location', '/Aguapotable/docs/pagos_contratos&fecha=' + $('#fecha').val()).attr('target','_blank');
    });
   
})(jQuery);